# ইস্তিকামাহ (Istiqamah) — Android 12+

Version 1.1.2

এই সংস্করণে Android Manifest theme reference এবং Compose `LocalContext` import ঠিক করা হয়েছে।

ফিচার: দৈনিক habit checklist, ইতিহাস/ক্যালেন্ডার, streak, weekly/monthly progress, custom habits, edit/delete, dark mode, daily reminder এবং JSON backup share।

## Build APK in the browser (GitHub Actions)

This project includes `.github/workflows/build-apk.yml`.

1. Create/sign in to a GitHub account on your phone.
2. Create a new repository and upload the contents of this project (the files inside `IstiqamahApp_v1_1`, not the ZIP itself if GitHub asks for individual files).
3. Open the repository's **Actions** tab.
4. Select **Build Istiqamah APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run and download the **Istiqamah-debug-apk** artifact.
8. Extract the downloaded artifact if necessary; it contains `app-debug.apk`.

The workflow uses Java 17 and Gradle 8.11.1 and builds the debug APK in GitHub's cloud runner.
