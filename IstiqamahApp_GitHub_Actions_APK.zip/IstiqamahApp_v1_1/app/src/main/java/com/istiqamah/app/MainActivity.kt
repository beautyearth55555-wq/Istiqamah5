package com.istiqamah.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationCompat
import androidx.core.app.ActivityCompat
import android.Manifest
import java.text.SimpleDateFormat
import java.util.*

private val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
private fun key(c: Calendar = Calendar.getInstance()) = synchronized(df) { df.format(c.time) }
private fun cal(s: String) = Calendar.getInstance().apply { time = synchronized(df) { df.parse(s)!! }; set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
private fun day(s: String, n: Int) = cal(s).apply { add(Calendar.DAY_OF_YEAR, n) }.let(::key)
private fun month(s: String, n: Int) = cal(s).apply { set(Calendar.DAY_OF_MONTH, 1); add(Calendar.MONTH, n) }.let(::key)
private fun bd(s: String) = s.map { if (it in '0'..'9') "০১২৩৪৫৬৭৮৯"[it - '0'] else it }.joinToString("")
private val bnMonths = listOf("জানুয়ারি","ফেব্রুয়ারি","মার্চ","এপ্রিল","মে","জুন","জুলাই","আগস্ট","সেপ্টেম্বর","অক্টোবর","নভেম্বর","ডিসেম্বর")
private val weekdays = listOf("সোম","মঙ্গল","বুধ","বৃহস্পতি","শুক্র","শনি","রবি")
private fun monthDays(s: String): List<String> { val c = cal(s).apply { set(Calendar.DAY_OF_MONTH, 1) }; return (0 until c.getActualMaximum(Calendar.DAY_OF_MONTH)).map { (c.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, it) }.let(::key) } }

data class Habit(val id: String, val name: String, val category: String, val target: Int = 1)

private fun defaults() = listOf(
    Habit("namaz", "নামাজ", "ইবাদত"), Habit("quran", "কোরআন তেলাওয়াত", "ইবাদত"),
    Habit("study", "পড়াশোনা", "পড়াশোনা"), Habit("english", "ইংরেজি", "পড়াশোনা"),
    Habit("math", "অংক", "পড়াশোনা"), Habit("exercise", "ব্যায়াম", "ব্যক্তিগত উন্নতি")
)
private fun load(p: android.content.SharedPreferences): List<Habit> {
    val r = p.getString("habits", null) ?: return defaults()
    return r.split("||").mapNotNull { x -> val a = x.split("::"); if (a.size >= 3) Habit(a[0], a[1], a[2], a.getOrNull(3)?.toIntOrNull() ?: 1) else null }.ifEmpty { defaults() }
}
private fun save(p: android.content.SharedPreferences, h: List<Habit>) = p.edit().putString("habits", h.joinToString("||") { "${it.id}::${it.name}::${it.category}::${it.target}" }).apply()
private fun done(p: android.content.SharedPreferences, d: String, id: String) = p.getBoolean("done_${d}_$id", false)
private fun putDone(p: android.content.SharedPreferences, d: String, id: String, v: Boolean) = p.edit().putBoolean("done_${d}_$id", v).apply()
private fun score(p: android.content.SharedPreferences, h: List<Habit>, d: String) = if (h.isEmpty()) 0 else h.count { done(p, d, it.id) } * 100 / h.size
private fun streak(p: android.content.SharedPreferences, h: List<Habit>, today: String): Int { var n = 0; var d = today; while (d >= "2000-01-01" && score(p, h, d) == 100) { n++; d = day(d, -1) }; return n }
private fun bestStreak(p: android.content.SharedPreferences, h: List<Habit>, today: String): Int { var best = 0; var run = 0; var d = today; repeat(370) { if (score(p, h, d) == 100) run++ else run = 0; if (run > best) best = run; d = day(d, -1) }; return best }

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        createNotificationChannel(this)
        if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        setContent { App() }
    }
}

private fun createNotificationChannel(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val ch = NotificationChannel("istiqamah_daily", "ইস্তিকামাহ রিমাইন্ডার", NotificationManager.IMPORTANCE_DEFAULT)
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }
}

private fun scheduleReminder(ctx: Context, hour: Int, minute: Int, enabled: Boolean) {
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(ctx, ReminderReceiver::class.java)
    val pi = PendingIntent.getBroadcast(ctx, 7001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    if (!enabled) { am.cancel(pi); return }
    val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
    am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
}

@Composable fun App() {
    val ctx = LocalContext.current
    val p = remember { ctx.getSharedPreferences("istiqamah", Context.MODE_PRIVATE) }
    var habits by remember { mutableStateOf(load(p)) }
    var tab by remember { mutableIntStateOf(0) }
    var today by remember { mutableStateOf(key()) }
    var dark by remember { mutableStateOf(p.getBoolean("dark", false)) }
    var refresh by remember { mutableIntStateOf(0) }; refresh
    LaunchedEffect(Unit) { while (true) { today = key(); kotlinx.coroutines.delay(60000) } }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Scaffold(topBar = { TopAppBar(title = { Text("ইস্তিকামাহ", fontWeight = FontWeight.Bold) }) }, bottomBar = {
            NavigationBar { listOf("আজ" to "✓", "অগ্রগতি" to "▥", "রিপোর্ট" to "★", "সেটিংস" to "⚙").forEachIndexed { i, x -> NavigationBarItem(tab == i, { tab = i }, icon = { Text(x.second) }, label = { Text(x.first) }) } }
        }) { pad ->
            when (tab) {
                0 -> Daily(habits, p, today, Modifier.padding(pad)) { habits = load(p); refresh++ }
                1 -> Progress(habits, p, today, Modifier.padding(pad))
                2 -> Reports(habits, p, today, Modifier.padding(pad))
                3 -> Settings(habits, p, dark, Modifier.padding(pad), { habits = load(p); refresh++ }) { dark = !dark; p.edit().putBoolean("dark", dark).apply() }
            }
        }
    }
}

@Composable private fun Daily(h: List<Habit>, p: android.content.SharedPreferences, today: String, m: Modifier, onChange: () -> Unit) {
    var selected by remember { mutableStateOf(today) }; var mon by remember { mutableStateOf(month(today, 0)) }
    var adding by remember { mutableStateOf(false) }; var name by remember { mutableStateOf("") }; var category by remember { mutableStateOf("অন্যান্য") }; var target by remember { mutableStateOf("1") }
    val s = score(p, h, selected); val st = streak(p, h, today)
    LazyColumn(m.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(if (selected == today) "আজকের কাজ" else "${bd(selected)} এর কাজ", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { StatCard("আজ", "$s%", Modifier.weight(1f)); StatCard("স্ট্রিক", bd(st.toString()) + " দিন", Modifier.weight(1f)); StatCard("বিষয়", bd(h.size.toString()), Modifier.weight(1f)) } }
        item { Calendar(p, h, today, selected, mon, { selected = it }, { mon = month(mon, it) }) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) { Button({ selected = day(selected, -1); mon = month(selected, 0) }, Modifier.weight(1f)) { Text("‹ আগের") }; OutlinedButton({ selected = today; mon = month(today, 0) }, Modifier.weight(1f)) { Text("আজ") }; Button({ if (selected < today) { selected = day(selected, 1); mon = month(selected, 0) } }, Modifier.weight(1f), enabled = selected < today) { Text("পরের ›") } } }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("দৈনিক অগ্রগতি", fontWeight = FontWeight.Bold); Text("$s%", fontSize = 30.sp, fontWeight = FontWeight.Bold); LinearProgressIndicator({ s / 100f }, Modifier.fillMaxWidth()) } } }
        h.groupBy { it.category }.forEach { (cat, itemsH) -> item { Text(cat, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }; items(itemsH, key = { it.id }) { x -> Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(x.name, fontWeight = FontWeight.SemiBold); if (x.target > 1) Text("লক্ষ্য: ${bd(x.target.toString())}", fontSize = 11.sp) }; Checkbox(done(p, selected, x.id), { v -> putDone(p, selected, x.id, v); onChange() }, enabled = selected <= today) } } } } }
        item { Button({ adding = true }, Modifier.fillMaxWidth()) { Text("＋ নতুন বিষয়") } }
    }
    if (adding) AlertDialog(onDismissRequest = { adding = false }, title = { Text("নতুন বিষয়") }, text = { Column { OutlinedTextField(name, { name = it }, label = { Text("বিষয়ের নাম") }); Spacer(Modifier.height(8.dp)); OutlinedTextField(category, { category = it }, label = { Text("ক্যাটাগরি") }); Spacer(Modifier.height(8.dp)); OutlinedTextField(target, { target = it.filter(Char::isDigit) }, label = { Text("দৈনিক লক্ষ্য (ঐচ্ছিক)") }) } }, confirmButton = { Button({ if (name.isNotBlank()) { save(p, h + Habit("custom_${System.currentTimeMillis()}", name.trim(), category.ifBlank { "অন্যান্য" }, target.toIntOrNull()?.coerceAtLeast(1) ?: 1)); name = ""; category = "অন্যান্য"; target = "1"; adding = false; onChange() } }) { Text("যোগ করুন") } }, dismissButton = { TextButton({ adding = false }) { Text("বাতিল") } })
}

@Composable private fun StatCard(title: String, value: String, m: Modifier) { Card(m) { Column(Modifier.padding(10.dp)) { Text(title, fontSize = 11.sp); Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp) } } }

@Composable private fun Calendar(p: android.content.SharedPreferences, h: List<Habit>, today: String, selected: String, mon: String, onSelect: (String) -> Unit, onMonth: (Int) -> Unit) {
    val c = cal(mon).apply { set(Calendar.DAY_OF_MONTH, 1) }; val offset = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7; val ds = monthDays(mon)
    val cells = buildList<String?> { repeat(offset) { add(null) }; ds.forEach { add(it) }; while (size % 7 != 0) add(null) }
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text("‹", fontSize = 30.sp, modifier = Modifier.clickable { onMonth(-1) }); Text("${bnMonths[c.get(Calendar.MONTH)]} ${bd(c.get(Calendar.YEAR).toString())}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("›", fontSize = 30.sp, modifier = Modifier.clickable(enabled = mon < month(today, 0)) { onMonth(1) }) }
        Row { weekdays.forEach { Text(it, Modifier.weight(1f), fontSize = 9.sp, fontWeight = FontWeight.Bold) } }
        cells.chunked(7).forEach { w -> Row { w.forEach { d -> Box(Modifier.weight(1f).height(48.dp), contentAlignment = Alignment.Center) { if (d != null) { val sc = score(p, h, d); val sel = d == selected; Column(horizontalAlignment = Alignment.CenterHorizontally) { Surface(Modifier.size(32.dp).clickable(enabled = d <= today) { onSelect(d) }, shape = CircleShape, color = if (sel) MaterialTheme.colorScheme.primary else if (d == today) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant) { Box(contentAlignment = Alignment.Center) { Text(bd(d.takeLast(2)), fontSize = 10.sp, color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface) } }; Text(if (sc == 100) "✓" else if (sc > 0) "$sc%" else "", fontSize = 8.sp) } } } } } }
    } }
}

@Composable private fun Progress(h: List<Habit>, p: android.content.SharedPreferences, today: String, m: Modifier) {
    val end = cal(today); val dow = (end.get(Calendar.DAY_OF_WEEK) + 5) % 7; val mon = day(today, -dow); val ds = (0..6).map { day(mon, it) }; val past = ds.filter { it <= today }; val avg = if (past.isEmpty()) 0 else past.sumOf { score(p, h, it) } / past.size
    LazyColumn(m.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { item { Text("সাপ্তাহিক অগ্রগতি", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("গড়: $avg%", fontSize = 20.sp); Text("চলমান স্ট্রিক: ${bd(streak(p, h, today).toString())} দিন") }; item { BarChart(ds.filter { it <= today }.map { weekdays[ds.indexOf(it)] to score(p, h, it) }) }; item { Text("সেরা স্ট্রিক: ${bd(bestStreak(p, h, today).toString())} দিন") }; item { Text("যে দিন ১০০% সম্পন্ন হয়েছে, সেটিই Perfect Day হিসেবে গণ্য হয়।") } }
}

@Composable private fun Reports(h: List<Habit>, p: android.content.SharedPreferences, today: String, m: Modifier) {
    val md = month(today, 0); val ds = monthDays(md).filter { it <= today }; val avg = if (ds.isEmpty()) 0 else ds.sumOf { score(p, h, it) } / ds.size
    val y = cal(today).get(Calendar.YEAR); val curMonth = cal(today).get(Calendar.MONTH); val ms = (0..curMonth).map { Calendar.getInstance().apply { set(y, it, 1, 12, 0, 0); set(Calendar.MILLISECOND, 0) }.let(::key) }
    LazyColumn(m.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { item { Text("রিপোর্ট", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("এই মাসের গড়: $avg%", fontSize = 20.sp); Text("চলতি বছরের সেরা স্ট্রিক: ${bd(bestStreak(p, h, today).toString())} দিন") }; item { Text("মাসভিত্তিক অগ্রগতি", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }; item { BarChart(ms.mapIndexed { i, x -> "${i + 1}" to monthDays(x).filter { it <= today }.let { z -> if (z.isEmpty()) 0 else z.sumOf { d -> score(p, h, d) } / z.size }) }) }; item { Text("মাসের প্রতিটি দিন থেকে গড় অগ্রগতি হিসাব করা হয়েছে।") } }
}

@Composable private fun BarChart(data: List<Pair<String, Int>>) { Row(Modifier.fillMaxWidth().height(190.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Bottom) { data.forEach { (l, v) -> Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) { Text("$v", fontSize = 9.sp); Box(Modifier.width(20.dp).height((v.coerceIn(1, 100) * 1.3f).dp).clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.primary)); Text(l, fontSize = 9.sp) } } } }

@Composable private fun Settings(h: List<Habit>, p: android.content.SharedPreferences, dark: Boolean, m: Modifier, onChange: () -> Unit, onTheme: () -> Unit) {
    val ctx = LocalContext.current
    var show by remember { mutableStateOf(false) }; var selected by remember { mutableStateOf<Habit?>(null) }; var confirmClear by remember { mutableStateOf(false) }
    var reminderOn by remember { mutableStateOf(p.getBoolean("reminder_on", false)) }
    var reminderHour by remember { mutableIntStateOf(p.getInt("reminder_hour", 20)) }
    var reminderMinute by remember { mutableIntStateOf(p.getInt("reminder_minute", 0)) }
    LazyColumn(m.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { item { Text("সেটিংস", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("ডার্ক মোড", fontWeight = FontWeight.Bold); Text(if (dark) "চালু" else "বন্ধ") }; Switch(dark, { onTheme() }) } } }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("দৈনিক রিমাইন্ডার", fontWeight = FontWeight.Bold)
            Text(if (reminderOn) "প্রতিদিন ${bd(String.format(Locale.US, "%02d:%02d", reminderHour, reminderMinute))}-এ মনে করিয়ে দেবে" else "বন্ধ")
            Row(verticalAlignment = Alignment.CenterVertically) { Switch(reminderOn, { reminderOn = it; p.edit().putBoolean("reminder_on", it).apply(); scheduleReminder(ctx, reminderHour, reminderMinute, it) }); Spacer(Modifier.width(8.dp)); Text("চালু রাখুন") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ reminderHour = (reminderHour + 1) % 24; p.edit().putInt("reminder_hour", reminderHour).apply(); if (reminderOn) scheduleReminder(ctx, reminderHour, reminderMinute, true) }) { Text("সময় +১") }
                OutlinedButton({ reminderMinute = (reminderMinute + 5) % 60; p.edit().putInt("reminder_minute", reminderMinute).apply(); if (reminderOn) scheduleReminder(ctx, reminderHour, reminderMinute, true) }) { Text("মিনিট +৫") }
            }
        } } }
        items(h, key = { it.id }) { x -> Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(x.name, fontWeight = FontWeight.Bold); Text("${x.category} • লক্ষ্য ${bd(x.target.toString())}", fontSize = 12.sp) }; TextButton({ selected = x; show = true }) { Text("সম্পাদনা") } } } }
        item { OutlinedButton({
            val json = buildString {
                append("{\"habits\":[")
                append(h.joinToString(",") { "{\"id\":\"${it.id}\",\"name\":\"${it.name.replace("\"", "\\\"")}\",\"category\":\"${it.category.replace("\"", "\\\"")}\",\"target\":${it.target}}" })
                append("]}")
            }
            val i = Intent(Intent.ACTION_SEND).apply { type = "application/json"; putExtra(Intent.EXTRA_TEXT, json); putExtra(Intent.EXTRA_SUBJECT, "Istiqamah Backup") }
            LocalContext.current.startActivity(Intent.createChooser(i, "ব্যাকআপ শেয়ার করুন"))
        }, Modifier.fillMaxWidth()) { Text("↗ ব্যাকআপ শেয়ার করুন") }
        item { OutlinedButton({ confirmClear = true }, Modifier.fillMaxWidth()) { Text("সব ডাটা মুছে ফেলুন") } }
        item { Text("ভার্সন 1.0 • Offline-first", fontSize = 12.sp) }
    }
    if (show && selected != null) { var n by remember(selected) { mutableStateOf(selected!!.name) }; var c by remember(selected) { mutableStateOf(selected!!.category) }; var t by remember(selected) { mutableStateOf(selected!!.target.toString()) }; AlertDialog(onDismissRequest = { show = false }, title = { Text("বিষয় সম্পাদনা") }, text = { Column { OutlinedTextField(n, { n = it }, label = { Text("নাম") }); Spacer(Modifier.height(8.dp)); OutlinedTextField(c, { c = it }, label = { Text("ক্যাটাগরি") }); Spacer(Modifier.height(8.dp)); OutlinedTextField(t, { t = it.filter(Char::isDigit) }, label = { Text("দৈনিক লক্ষ্য") }) } }, confirmButton = { Button({ val old = selected!!; val nh = h.map { if (it.id == old.id) old.copy(name = n.trim().ifBlank { old.name }, category = c.trim().ifBlank { old.category }, target = t.toIntOrNull()?.coerceAtLeast(1) ?: old.target) else it }; save(p, nh); show = false; onChange() }) { Text("সংরক্ষণ") } }, dismissButton = { TextButton({ val old = selected!!; if (h.size > 1) { save(p, h.filterNot { it.id == old.id }); show = false; onChange() } }) { Text("মুছে ফেলুন") } }) }
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false }, title = { Text("নিশ্চিত করো") }, text = { Text("সব অভ্যাস ও সম্পন্ন করার ইতিহাস মুছে যাবে।") }, confirmButton = { Button({ p.edit().clear().apply(); confirmClear = false; onChange() }) { Text("মুছে ফেলুন") } }, dismissButton = { TextButton({ confirmClear = false }) { Text("বাতিল") } })
}
