package com.istiqamah.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val open = Intent(context, MainActivity::class.java)
        val pi = PendingIntent.getActivity(context, 7002, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, "istiqamah_daily")
            .setSmallIcon(com.istiqamah.app.R.mipmap.ic_launcher)
            .setContentTitle("ইস্তিকামাহ")
            .setContentText("আজকের কাজগুলো সম্পন্ন করার সময় হয়েছে।")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        NotificationManagerCompat.from(context).notify(7001, notification)
    }
}
